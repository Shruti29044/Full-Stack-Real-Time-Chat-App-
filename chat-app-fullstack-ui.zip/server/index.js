const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: '*',
  },
});

app.use(cors());

// Store rooms and users in memory (for demo purpose)
const rooms = {}; // { roomName: [usernames] }

io.on('connection', (socket) => {
  console.log('A user connected:', socket.id);

  socket.on('joinRoom', ({ room, username }) => {
    socket.join(room);
    
    if (!rooms[room]) {
      rooms[room] = [];
    }
    rooms[room].push(username);

    io.to(room).emit('message', { user: 'System', text: `${username} has joined ${room}` });
  });

  socket.on('sendMessage', ({ room, username, message }) => {
    io.to(room).emit('message', { user: username, text: message });
  });

  socket.on('disconnect', () => {
    console.log('A user disconnected:', socket.id);
  });
});

const PORT = 5000;
server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
