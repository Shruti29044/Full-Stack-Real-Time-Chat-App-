#!/bin/bash

echo "Starting fullstack chat app setup..."

# Backend setup
echo "Setting up backend..."
cd server || exit 1

# Initialize npm if package.json doesn't exist
if [ ! -f package.json ]; then
  npm init -y
fi

npm install express cors socket.io

# Run backend in background
node index.js &
BACKEND_PID=$!

cd ..

# Frontend setup
echo "Setting up frontend..."
cd client || exit 1

npm install

# Run frontend
npm start

# Kill backend after frontend is closed
kill $BACKEND_PID
